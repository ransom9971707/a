import { useEffect, useRef, useState, type RefObject } from 'react'
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  Mail,
  MapPin,
  Menu,
  Minus,
  Phone,
  Plus,
  X,
} from 'lucide-react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Lenis from 'lenis'

gsap.registerPlugin(ScrollTrigger)

const navItems = [
  { label: 'Approach', href: '#approach' },
  { label: 'Treatments', href: '#treatments' },
  { label: 'The studio', href: '#studio' },
  { label: 'Your dentist', href: '#dentist' },
]

const treatments = [
  {
    name: 'Preventive care',
    short: 'Prevention',
    tagline: 'Keep good things going.',
    description:
      'Thoughtful check-ups, gentle hygiene and a clear view of your oral health—without the lecture. We look for the small things, so they stay small.',
    details: ['Comprehensive exam', 'Gentle hygiene', 'Digital imaging only when needed'],
    meta: '60 MIN · EVERY 6 MONTHS',
  },
  {
    name: 'Clear aligners',
    short: 'Align',
    tagline: 'A subtle shift. A big difference.',
    description:
      'Straighten your smile with a digitally planned sequence of nearly invisible aligners. Your plan is built around your face, your bite and your actual life.',
    details: ['3D smile planning', 'Progress check-ins', 'Retainers and aftercare'],
    meta: 'DIGITAL PLAN · NO IMPRESSIONS',
  },
  {
    name: 'Smile design',
    short: 'Refine',
    tagline: 'Still you. Just more luminous.',
    description:
      'Conservative cosmetic dentistry that respects what makes your smile yours. We consider shape, proportion and tone before recommending any treatment.',
    details: ['Smile preview', 'Minimal-prep options', 'Natural porcelain artistry'],
    meta: 'BESPOKE PLAN · PREVIEW FIRST',
  },
  {
    name: 'Whitening',
    short: 'Brighten',
    tagline: 'Brighter, never artificial.',
    description:
      'Professional whitening calibrated to your enamel and sensitivity. Choose an in-studio refresh or a gradual at-home protocol, with a shade that still feels like you.',
    details: ['Sensitivity assessment', 'In-studio or take-home', 'Personal maintenance plan'],
    meta: 'FROM 75 MIN · ENAMEL-AWARE',
  },
  {
    name: 'Restorative care',
    short: 'Restore',
    tagline: 'Strength that looks effortless.',
    description:
      'From a single filling to a complete restoration, we combine precise digital planning with meticulous craftsmanship to bring back comfort, function and confidence.',
    details: ['Tooth-coloured restorations', 'Crowns and bridges', 'Implant restoration'],
    meta: 'PLANNED DIGITALLY · MADE TO LAST',
  },
]

const testimonials = [
  {
    quote:
      'I used to put off the dentist for years. Here, everything is explained before it happens, nobody rushes you, and the space is genuinely beautiful. I left feeling looked after.',
    name: 'Nina R.',
    detail: 'NEW PATIENT · PREVENTIVE CARE',
  },
  {
    quote:
      'The result is exactly what I hoped for: brighter, more balanced, and still completely me. The preview made every decision feel easy and considered.',
    name: 'Marcus T.',
    detail: 'SMILE DESIGN PATIENT',
  },
  {
    quote:
      'Clear aligners fitted around my work and travel without any drama. Every check-in was on time, and seeing the progress was oddly addictive.',
    name: 'Leah K.',
    detail: 'CLEAR ALIGNER PATIENT',
  },
]

const faqs = [
  {
    question: 'What happens at my first visit?',
    answer:
      'We set aside 60 minutes to talk, listen and understand what you want from your smile. Your visit includes a comprehensive assessment and any necessary digital imaging. Treatment only begins when you feel informed and ready.',
  },
  {
    question: 'I feel nervous about the dentist. Can you help?',
    answer:
      'Absolutely. Tell us when you book and we will adapt the pace, explain each step and agree on a pause signal before we begin. You are always in control of your appointment.',
  },
  {
    question: 'Can I use my dental insurance?',
    answer:
      'We provide clear, itemized documentation for you to submit to your insurer. Coverage varies by plan, so our team can help you understand the information to request from your provider before treatment.',
  },
  {
    question: 'Do you offer payment plans?',
    answer:
      'For multi-stage treatment, we can structure payments around your clinical plan. You will receive transparent fees and timing in writing before deciding to proceed.',
  },
]

function useDialogFocus(
  open: boolean,
  onClose: () => void,
  containerRef: RefObject<HTMLElement | null>,
) {
  useEffect(() => {
    if (!open) return
    const previous = document.activeElement as HTMLElement | null
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const container = containerRef.current
    const focusable = container?.querySelectorAll<HTMLElement>(
      'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
    )
    focusable?.[0]?.focus()

    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
      if (event.key !== 'Tab' || !focusable?.length) return
      const first = focusable[0]
      const last = focusable[focusable.length - 1]
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault()
        last.focus()
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault()
        first.focus()
      }
    }

    document.addEventListener('keydown', handleKey)
    return () => {
      document.body.style.overflow = previousOverflow
      document.removeEventListener('keydown', handleKey)
      previous?.focus()
    }
  }, [open, onClose, containerRef])
}

function Brand({ light = false }: { light?: boolean }) {
  return (
    <a className={`brand ${light ? 'brand--light' : ''}`} href="#top" aria-label="Lumen home">
      <span className="brand__mark" aria-hidden="true">
        <span />
      </span>
      <span>lumen</span>
      <span className="brand__dot">.</span>
    </a>
  )
}

function Header({ onBook }: { onBook: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [hidden, setHidden] = useState(false)
  const lastScroll = useRef(0)
  const menuRef = useRef<HTMLDivElement>(null)

  useDialogFocus(menuOpen, () => setMenuOpen(false), menuRef)

  useEffect(() => {
    const onScroll = () => {
      const current = window.scrollY
      if (current > 140 && current > lastScroll.current + 4) setHidden(true)
      if (current < lastScroll.current - 4 || current < 80) setHidden(false)
      lastScroll.current = current
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <>
      <header className={`site-header ${hidden ? 'site-header--hidden' : ''}`}>
        <div className="site-header__inner">
          <Brand />
          <nav className="desktop-nav" aria-label="Main navigation">
            {navItems.map((item) => (
              <a key={item.href} href={item.href}>
                {item.label}<span aria-hidden="true">.</span>
              </a>
            ))}
          </nav>
          <button className="header-book" type="button" onClick={onBook}>
            Book a visit <ArrowUpRight size={16} strokeWidth={1.8} />
          </button>
          <button
            className="menu-toggle"
            type="button"
            aria-label="Open menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(true)}
          >
            <Menu size={24} strokeWidth={1.5} />
          </button>
        </div>
      </header>

      <div className={`menu-overlay ${menuOpen ? 'is-open' : ''}`} aria-hidden={!menuOpen}>
        <button
          className="menu-overlay__backdrop"
          type="button"
          aria-label="Close menu"
          tabIndex={menuOpen ? 0 : -1}
          onClick={() => setMenuOpen(false)}
        />
        <div className="mobile-menu" ref={menuRef} role="dialog" aria-modal="true" aria-label="Navigation menu">
          <div className="mobile-menu__top">
            <Brand light />
            <button type="button" aria-label="Close menu" onClick={() => setMenuOpen(false)}>
              <X size={26} strokeWidth={1.4} />
            </button>
          </div>
          <nav aria-label="Mobile navigation">
            {navItems.map((item, index) => (
              <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)}>
                <span>0{index + 1}</span>{item.label}<ArrowUpRight size={22} strokeWidth={1.4} />
              </a>
            ))}
          </nav>
          <div className="mobile-menu__bottom">
            <button
              className="button button--mint"
              type="button"
              onClick={() => {
                setMenuOpen(false)
                onBook()
              }}
            >
              Book a visit <ArrowUpRight size={18} />
            </button>
            <a href="tel:+12125550184">+1 212 555 0184</a>
          </div>
        </div>
      </div>
    </>
  )
}

function BookingDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const drawerRef = useRef<HTMLDivElement>(null)
  useDialogFocus(open, onClose, drawerRef)

  return (
    <div className={`booking-overlay ${open ? 'is-open' : ''}`} aria-hidden={!open}>
      <button className="booking-overlay__backdrop" type="button" aria-label="Close booking panel" onClick={onClose} tabIndex={open ? 0 : -1} />
      <div className="booking-drawer" ref={drawerRef} role="dialog" aria-modal="true" aria-labelledby="booking-title">
        <div className="booking-drawer__top">
          <span className="mono-label">APPOINTMENTS</span>
          <button type="button" aria-label="Close booking panel" onClick={onClose}>
            <X size={26} strokeWidth={1.4} />
          </button>
        </div>
        <div className="booking-drawer__content">
          <p className="booking-drawer__intro">A calmer dental visit starts here.</p>
          <h2 id="booking-title">Let’s find a time<br /><em>for you.</em></h2>
          <p className="booking-drawer__copy">
            Speak directly with our studio team. We’ll answer your questions, understand what you need and arrange the right kind of visit.
          </p>
          <div className="booking-actions">
            <a className="booking-action" href="tel:+12125550184">
              <Phone size={22} strokeWidth={1.5} />
              <span><small>CALL THE STUDIO</small>+1 212 555 0184</span>
              <ArrowUpRight size={22} strokeWidth={1.5} />
            </a>
            <a className="booking-action" href="mailto:hello@lumen.dental?subject=Appointment%20request">
              <Mail size={22} strokeWidth={1.5} />
              <span><small>EMAIL US</small>hello@lumen.dental</span>
              <ArrowUpRight size={22} strokeWidth={1.5} />
            </a>
          </div>
          <div className="booking-hours">
            <span className="mono-label">STUDIO HOURS</span>
            <dl>
              <div><dt>Monday—Thursday</dt><dd>8:00—18:00</dd></div>
              <div><dt>Friday</dt><dd>8:00—15:00</dd></div>
              <div><dt>Saturday—Sunday</dt><dd>Closed</dd></div>
            </dl>
          </div>
        </div>
        <p className="booking-drawer__note">New patient visits are a relaxed 60 minutes.</p>
      </div>
    </div>
  )
}

function TreatmentExplorer({ onBook }: { onBook: () => void }) {
  const [active, setActive] = useState(0)
  const treatment = treatments[active]

  return (
    <section className="treatments section-dark" id="treatments">
      <div className="section-shell">
        <div className="treatments__heading" data-reveal>
          <span className="vertical-label">TREATMENTS</span>
          <div>
            <p className="mono-label mono-label--mint">CARE, CONSIDERED</p>
            <h2>Everything you need.<br /><em>Nothing you don’t.</em></h2>
          </div>
          <p>
            No upselling. No one-size-fits-all plans. Just meticulous dentistry, explained clearly and shaped around you.
          </p>
        </div>

        <div className="treatment-explorer" data-reveal>
          <div className="treatment-tabs" role="tablist" aria-label="Explore treatments">
            {treatments.map((item, index) => (
              <button
                key={item.name}
                type="button"
                role="tab"
                aria-selected={active === index}
                aria-controls="treatment-panel"
                className={active === index ? 'is-active' : ''}
                onClick={() => setActive(index)}
              >
                <span className="treatment-tabs__number">0{index + 1}</span>
                <span>{item.name}</span>
                <ArrowUpRight size={22} strokeWidth={1.4} />
              </button>
            ))}
          </div>
          <div className="treatment-panel" id="treatment-panel" role="tabpanel" aria-live="polite">
            <div className="treatment-panel__index" aria-hidden="true">0{active + 1}</div>
            <p className="mono-label mono-label--mint">{treatment.short.toUpperCase()}</p>
            <h3>{treatment.tagline}</h3>
            <p className="treatment-panel__description">{treatment.description}</p>
            <ul>
              {treatment.details.map((detail) => (
                <li key={detail}><Check size={17} strokeWidth={1.6} />{detail}</li>
              ))}
            </ul>
            <div className="treatment-panel__footer">
              <span className="mono-label">{treatment.meta}</span>
              <button type="button" className="text-link text-link--light" onClick={onBook}>
                Discuss this treatment <ArrowUpRight size={17} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function App() {
  const [bookingOpen, setBookingOpen] = useState(false)
  const [testimonial, setTestimonial] = useState(0)
  const [openFaq, setOpenFaq] = useState<number | null>(0)

  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reducedMotion) return

    const lenis = new Lenis({ duration: 1.05, smoothWheel: true, anchors: true })
    lenis.on('scroll', ScrollTrigger.update)
    const tick = (time: number) => lenis.raf(time * 1000)
    gsap.ticker.add(tick)
    gsap.ticker.lagSmoothing(0)

    const context = gsap.context(() => {
      gsap.fromTo(
        '.hero-line__inner',
        { yPercent: 110 },
        { yPercent: 0, duration: 0.9, stagger: 0.12, ease: 'power3.out', delay: 0.15 },
      )
      gsap.fromTo(
        '.hero__image-wrap',
        { clipPath: 'inset(0 0 100% 0 round 20px)' },
        { clipPath: 'inset(0 0 0% 0 round 20px)', duration: 1.1, ease: 'power3.out', delay: 0.35 },
      )
      gsap.utils.toArray<HTMLElement>('[data-reveal]').forEach((element) => {
        ScrollTrigger.create({
          trigger: element,
          start: 'top 88%',
          once: true,
          onEnter: () => {
            gsap.fromTo(
              element,
              { y: 42, opacity: 0 },
              { y: 0, opacity: 1, duration: 0.85, ease: 'power3.out' },
            )
          },
        })
      })
      gsap.utils.toArray<HTMLElement>('[data-parallax]').forEach((image) => {
        gsap.fromTo(
          image,
          { yPercent: -5 },
          {
            yPercent: 5,
            ease: 'none',
            scrollTrigger: { trigger: image.parentElement, start: 'top bottom', end: 'bottom top', scrub: 1 },
          },
        )
      })
    })

    return () => {
      context.revert()
      gsap.ticker.remove(tick)
      lenis.destroy()
    }
  }, [])

  const openBooking = () => setBookingOpen(true)
  const changeTestimonial = (direction: number) => {
    setTestimonial((current) => (current + direction + testimonials.length) % testimonials.length)
  }

  return (
    <div id="top">
      <a className="skip-link" href="#main">Skip to content</a>
      <div className="page-grain" aria-hidden="true" />
      <Header onBook={openBooking} />

      <main id="main">
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero__grid section-shell">
            <div className="hero__copy">
              <div className="hero__availability">
                <span aria-hidden="true" /> WELCOMING NEW PATIENTS
              </div>
              <h1 id="hero-title">
                <span className="hero-line"><span className="hero-line__inner">Like your smile</span></span>
                <span className="hero-line hero-line--offset"><span className="hero-line__inner"><em>a little more.</em></span></span>
              </h1>
              <div className="hero__support">
                <p>Considered dentistry for people who want exceptional care—and to actually enjoy coming in.</p>
                <div className="hero__actions">
                  <button className="button button--ink" type="button" onClick={openBooking}>
                    Book a visit <ArrowUpRight size={18} strokeWidth={1.7} />
                  </button>
                  <a className="text-link" href="#approach">Our approach <ArrowDown size={17} /></a>
                </div>
              </div>
            </div>
            <div className="hero__visual">
              <div className="hero__image-wrap">
                <img src="/images/hero-smile.webp" alt="Woman smiling confidently in soft natural light" fetchPriority="high" />
              </div>
              <div className="hero__image-caption">
                <span>FEEL AT EASE</span>
                <span>LEAVE FEELING GREAT</span>
              </div>
            </div>
            <div className="hero__side-note">DENTISTRY · NEW YORK</div>
          </div>
          <div className="hero__foot section-shell">
            <span>PREVENTIVE · COSMETIC · RESTORATIVE</span>
            <a href="#approach" aria-label="Scroll to our approach"><ArrowDown size={20} strokeWidth={1.4} /></a>
            <span>48 GREENE STREET · SOHO</span>
          </div>
        </section>

        <section className="manifesto section-dark">
          <div className="section-shell">
            <p className="manifesto__statement" data-reveal>
              Clinical precision.<br /><em>Human pace.</em>
            </p>
            <div className="manifesto__facts" data-reveal>
              <div><strong>60</strong><span>minutes for every<br />first appointment</span></div>
              <div><strong>100<span>%</span></strong><span>digital, comfortable<br />smile planning</span></div>
              <div><strong>01</strong><span>clear plan, with<br />no pressure attached</span></div>
            </div>
          </div>
        </section>

        <section className="approach" id="approach">
          <div className="section-shell">
            <div className="approach__top" data-reveal>
              <p className="mono-label">A DIFFERENT DENTAL VISIT</p>
              <h2>Less “open wide.”<br />More <em>“how are you?”</em></h2>
              <p className="approach__intro">
                Great dentistry begins before we look at your teeth. It begins with time, trust and a genuine understanding of what would make you feel more confident.
              </p>
            </div>
            <div className="approach__principles">
              <article data-reveal>
                <span>01</span>
                <h3>Unrushed by design</h3>
                <p>Longer appointments mean space to ask questions, understand your options and never feel like just another name on a schedule.</p>
              </article>
              <article data-reveal>
                <span>02</span>
                <h3>Conservative at heart</h3>
                <p>We preserve healthy tooth structure wherever possible and recommend only what adds meaningful value to your health or confidence.</p>
              </article>
              <article data-reveal>
                <span>03</span>
                <h3>Clarity at every step</h3>
                <p>See what we see. Understand what we recommend, why it matters and what it costs before making any decision.</p>
              </article>
            </div>
          </div>
        </section>

        <TreatmentExplorer onBook={openBooking} />

        <section className="studio" id="studio">
          <div className="section-shell">
            <div className="studio__heading" data-reveal>
              <p className="mono-label">THE STUDIO · SOHO, NYC</p>
              <h2>A clinic that doesn’t<br /><em>feel like one.</em></h2>
              <p>Natural light. Quiet corners. Thoughtful details. We designed Lumen to lower your shoulders the moment you walk in.</p>
            </div>
            <div className="studio__image" data-reveal>
              <img src="/images/studio-interior.webp" alt="Lumen's calm treatment studio with powder-blue cabinetry and a garden view" data-parallax />
              <div className="studio__image-label"><span>01</span> THE TREATMENT ROOM</div>
            </div>
            <div className="studio__details" data-reveal>
              <p>From noise-cancelling headphones to a pause signal you control, small comforts are built into every visit.</p>
              <a className="text-link" href="https://www.google.com/maps/search/?api=1&query=48+Greene+Street+New+York" target="_blank" rel="noreferrer">
                <MapPin size={18} strokeWidth={1.5} /> Get directions <ArrowUpRight size={17} />
              </a>
            </div>
          </div>
        </section>

        <section className="dentist" id="dentist">
          <div className="section-shell dentist__grid">
            <div className="dentist__portrait" data-reveal>
              <img src="/images/dr-amelia.webp" alt="Dr. Amelia Hart in the Lumen studio" data-parallax />
              <span className="mono-label">DR. AMELIA HART · DDS</span>
            </div>
            <div className="dentist__story" data-reveal>
              <p className="mono-label">YOUR DENTIST</p>
              <blockquote>“Technical excellence matters. But being truly listened to? That changes the whole experience.”</blockquote>
              <div className="dentist__bio">
                <p>Dr. Amelia Hart founded Lumen with a simple conviction: exceptional clinical care and genuine human warmth should never be separate things.</p>
                <p>Her approach blends minimally invasive dentistry, digital precision and an exacting eye for natural aesthetics—with time to talk through every choice.</p>
              </div>
              <ul>
                <li>Advanced training in aesthetic and restorative dentistry</li>
                <li>Clear aligner certified provider</li>
                <li>Member, American Dental Association</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="stories section-dark" aria-label="Patient stories">
          <div className="section-shell stories__grid" data-reveal>
            <p className="mono-label mono-label--mint">IN THEIR OWN WORDS</p>
            <div className="stories__quote" aria-live="polite">
              <span className="stories__mark" aria-hidden="true">“</span>
              <blockquote>{testimonials[testimonial].quote}</blockquote>
              <div className="stories__person">
                <strong>{testimonials[testimonial].name}</strong>
                <span>{testimonials[testimonial].detail}</span>
              </div>
            </div>
            <div className="stories__controls">
              <span>( {testimonial + 1} / {testimonials.length} )</span>
              <div>
                <button type="button" aria-label="Previous patient story" onClick={() => changeTestimonial(-1)}><ArrowLeft size={21} strokeWidth={1.4} /></button>
                <button type="button" aria-label="Next patient story" onClick={() => changeTestimonial(1)}><ArrowRight size={21} strokeWidth={1.4} /></button>
              </div>
            </div>
          </div>
        </section>

        <section className="faq" id="faq">
          <div className="section-shell faq__grid">
            <div className="faq__heading" data-reveal>
              <p className="mono-label">BEFORE YOU COME IN</p>
              <h2>A few things<br /><em>worth knowing.</em></h2>
              <p>Something else on your mind?</p>
              <a className="text-link" href="mailto:hello@lumen.dental?subject=A%20question%20about%20Lumen">Ask us directly <ArrowUpRight size={17} /></a>
            </div>
            <div className="faq__list" data-reveal>
              {faqs.map((faq, index) => {
                const isOpen = openFaq === index
                return (
                  <div className={`faq-item ${isOpen ? 'is-open' : ''}`} key={faq.question}>
                    <button
                      type="button"
                      aria-expanded={isOpen}
                      aria-controls={`faq-answer-${index}`}
                      onClick={() => setOpenFaq(isOpen ? null : index)}
                    >
                      <span>{faq.question}</span>
                      {isOpen ? <Minus size={21} strokeWidth={1.4} /> : <Plus size={21} strokeWidth={1.4} />}
                    </button>
                    {isOpen && <div className="faq-item__answer" id={`faq-answer-${index}`}><p>{faq.answer}</p></div>}
                  </div>
                )
              })}
            </div>
          </div>
        </section>

        <section className="closing-cta">
          <div className="section-shell closing-cta__inner" data-reveal>
            <p className="mono-label">YOUR SMILE, WHEN YOU’RE READY</p>
            <h2>Let’s make your next<br />dental visit <em>feel different.</em></h2>
            <button className="button button--ink" type="button" onClick={openBooking}>
              Book your first visit <ArrowUpRight size={19} strokeWidth={1.6} />
            </button>
          </div>
        </section>
      </main>

      <footer className="footer section-dark" id="contact">
        <div className="section-shell">
          <div className="footer__top">
            <Brand light />
            <p>Thoughtful dentistry.<br />A reason to smile.</p>
            <button className="text-link text-link--light" type="button" onClick={openBooking}>Book a visit <ArrowUpRight size={18} /></button>
          </div>
          <div className="footer__grid">
            <div>
              <span className="mono-label">VISIT</span>
              <a href="https://www.google.com/maps/search/?api=1&query=48+Greene+Street+New+York" target="_blank" rel="noreferrer">48 Greene Street<br />SoHo, New York, NY 10013</a>
            </div>
            <div>
              <span className="mono-label">TALK</span>
              <a href="tel:+12125550184">+1 212 555 0184</a>
              <a href="mailto:hello@lumen.dental">hello@lumen.dental</a>
            </div>
            <div>
              <span className="mono-label">HOURS</span>
              <p>Mon—Thu · 8:00—18:00<br />Fri · 8:00—15:00</p>
            </div>
            <nav aria-label="Footer navigation">
              <span className="mono-label">EXPLORE</span>
              {navItems.map((item) => <a key={item.href} href={item.href}>{item.label}</a>)}
            </nav>
          </div>
          <div className="footer__bottom">
            <span>© 2026 LUMEN DENTAL STUDIO</span>
            <a href="#top">BACK TO TOP <ArrowUpRight size={14} /></a>
          </div>
        </div>
      </footer>

      <BookingDrawer open={bookingOpen} onClose={() => setBookingOpen(false)} />
    </div>
  )
}

export default App
