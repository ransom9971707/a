# Lumen Dental Studio

A responsive, editorial website for a boutique dental practice. Built with React, TypeScript and Vite, with GSAP scroll choreography, Lenis smooth scrolling and Lucide icons.

## Run locally

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## Experience

- Asymmetric responsive layouts for phone, tablet and desktop
- Masked hero entrance, scroll reveals and image parallax
- Interactive treatment explorer, patient stories and FAQs
- Keyboard-accessible mobile navigation and direct call/email booking drawer
- Reduced-motion support, visible focus states and semantic landmarks
- Bespoke, locally hosted WebP photography created for this website

This is a frontend-only marketing site. Appointment actions open the visitor's phone or email client; no patient data is collected or stored.
